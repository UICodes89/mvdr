import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './public/home/home.component';
import { LoginComponent } from './public/login/login.component';
import { DashboardComponent } from './secure/dashboard/dashboard.component';
import {ProductsComponent} from "./secure/products/products.component";
import { ProductSdecComponent } from './secure/products/SDEC/products.sdec.component';
import { ProductCdcComponent } from './secure/products/CDC/products.cdc.component';
import { ProductStoreComponent } from './secure/products/STORES/products.store.component';
import { TranscationComponent } from './secure/transcation/transcation.component';
import { SecureLayoutComponent } from './core/secure-layout/secure-layout.component';
import { PublicLayoutComponent } from './core/public-layout/public-layout.component';
import { HeaderComponent } from './core/header/header.component';
import { FooterComponent } from './core/footer/footer.component';

import {CoreService} from "./core/services/core.service";
import {AuthGuard} from "./core/auth.guard";



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    DashboardComponent,
    ProductsComponent,
    ProductSdecComponent,
    ProductCdcComponent,
    ProductStoreComponent,
    TranscationComponent,
    SecureLayoutComponent,
    PublicLayoutComponent,
    HeaderComponent,
    FooterComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  exports:[],
  providers: [CoreService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
