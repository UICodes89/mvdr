import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {PublicLayoutComponent} from "./core/public-layout/public-layout.component";
import {SecureLayoutComponent} from "./core/secure-layout/secure-layout.component";

import {AuthGuard} from "./core/auth.guard";
 
const routes: Routes = [
  { path: '',   redirectTo: '/public/login', pathMatch: 'full' },
  {
    path: 'public',
    component: PublicLayoutComponent,
    children: [
        {
            path: '',
            loadChildren: './public/public.module#PublicModule',
            data: { title: 'App' },
        }
    ]
},
  {
    path: 'secure',
    component: SecureLayoutComponent,
    children: [
        {
            path: '',
            loadChildren: './secure/secure.module#SecureModule',
            data: { title: 'APP' },
            canActivate: [AuthGuard]
        }
    ]
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
