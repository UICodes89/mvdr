import { Injectable } from '@angular/core';

import {HttpClient, HttpHeaders } from '@angular/common/http';

import {token} from "../../model/token-model";
import { Observable } from 'rxjs';
import {BehaviorSubject} from "rxjs/BehaviorSubject";
import { catchError, retry } from 'rxjs/operators';

import { Router }  from '@angular/router';



const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
    "Access-Control-Allow-Origin" : "*"
  })
};

@Injectable()
export class CoreService {

  private activeMenu = new BehaviorSubject<Boolean>(false);
  currentActiveMenu = this.activeMenu.asObservable();

  private activeLogin = new BehaviorSubject<string>("");
  currentLoginType = this.activeLogin.asObservable();

  private token = new BehaviorSubject<string>("");
  currenttoken = this.token.asObservable();

  setActiveMenuName(status:boolean){
    console.log(this.activeMenu);
    this.activeMenu.next(status);
    console.log(this.activeMenu.value, "active  menu",status);
  }

  setLoginType(name:string){
    this.activeLogin.next(name);
  }
  setCurrentToken(token:string){
    this.token.next(token);
  }



  private urls = [
     {
       "endPoint": {
          "url":"http://40.123.44.169:3009/api/users/authenticate",
        },
      "admin":{
        "userName":"admin@gmail.com",
        "password":"1234"
      },
      "man":{
        "userName":"dcshipper@711b2c001.onmicrosoft.com",
        "password":"1234"
      },
      "dis":{
        "userName":"store101@711b2c001.onmicrosoft.com",
        "password":"1234"
      },
      "ven":{
        "userName":"store101@711b2c001.onmicrosoft.com",
        "password":"1234"
      },
      "ret":{
        "userName":"store101@711b2c001.onmicrosoft.com",
        "password":"1234"
      },

     }
  ];

  

  constructor(private http:HttpClient, public route:Router) { }
  
  login(type): Observable<token>{
    var data = {
      email:this.urls[0][type].userName,
      password:this.urls[0][type].password
    }
    return this.http.post<token>(this.urls[0].endPoint.url, JSON.stringify(data), httpOptions);
    
  }

  addProducts(data) : Observable<any>{
    let loginType = localStorage.getItem ("loginType");
    return this.http.post(this.urls[0][loginType].addProductUrl, data, httpOptions);
  }

  getTranscation():Observable<any>{
    let loginType = localStorage.getItem ("loginType");
    return this.http.get(this.urls[0][loginType].addProductUrl+"?email="+this.urls[0][loginType].userName);
  }

}
