import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {CoreService} from "../services/core.service";

import {Router} from "@angular/router";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None  
})
export class HeaderComponent implements OnInit {

  public showTopNav:Boolean = false;

  constructor(public service:CoreService, public route:Router) { }

  ngOnInit() {
    
    this.service.currentActiveMenu.subscribe(data => this.showTopNav = data);
    
  }

  logout(){
    this.route.navigate(['/public/login']);
    localStorage.removeItem("loginType");
    console.log("Logout Token Removed..");
  }
}
