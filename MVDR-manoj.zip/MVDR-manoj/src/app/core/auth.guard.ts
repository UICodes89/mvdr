import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import {CoreService} from "../core/services/core.service"

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private service:CoreService){}
  private isLoggedIn = false;
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
     this.service.currenttoken.subscribe(data => {
      this.isLoggedIn =  (data.length)?true:false;
    });
    return true;//this.isLoggedIn;
  }
}
