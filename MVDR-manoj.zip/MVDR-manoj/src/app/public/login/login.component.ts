import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {CoreService} from "../../core/services/core.service";
import { Router }  from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public isShow = false;

  constructor(public service:CoreService, public route:Router) { }

  ngOnInit() {
  }
  
  login(type){
    this.isShow = true;
      if(type == "admin"){
        this.service.login("admin").subscribe(function(data){
          localStorage.setItem("token", data.token);
          localStorage.setItem("loginType", type);
          this.route.navigate(['/secure/dashboard']);
        });
      }else if(type=="man"){
        this.service.login("man").subscribe(function(data){
          localStorage.setItem("token", data.token);
          localStorage.setItem("loginType", type);
          this.route.navigate(['/secure/dashboard']);
        });
      }else if(type=="dis"){
        this.service.login("dist").subscribe(function(data){
          localStorage.setItem("token", data.token);
          localStorage.setItem("loginType", type);
          this.route.navigate(['/secure/dashboard']);
        }); 
      }else if(type=="ven"){
        this.service.login("ven").subscribe(function(data){
          localStorage.setItem("token", data.token);
          localStorage.setItem("loginType", type);
          this.route.navigate(['/secure/dashboard']);
        }); 
      }else if(type=="ret"){
        this.service.login("ret").subscribe(function(data){
          localStorage.setItem("token", data.token);
          localStorage.setItem("loginType", type);
          this.route.navigate(['/secure/dashboard']);
        }); 
      }
       
  }

  
  

}
