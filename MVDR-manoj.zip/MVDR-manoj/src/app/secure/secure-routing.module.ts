import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {DashboardComponent} from "./dashboard/dashboard.component";
import {ProductsComponent} from "./products/products.component";
import {TranscationComponent} from "./transcation/transcation.component";


const routes: Routes = [
    {
        path: 'add-product',
        component: ProductsComponent,
        data: {title: 'Add Products'}
    },
    {
        path: 'dashboard',
        component: DashboardComponent,
        data: {title: 'Dashboard'}
    },
    {
        path: 'view-transaction',
        component: TranscationComponent,
        data: {title: 'Transcation'}
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [RouterModule]
})
export class SecureRoutingModule {
}
