import { Component, OnInit } from '@angular/core';
import {CoreService} from "../../core/services/core.service";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public boardName:string;

  constructor(public service:CoreService) { }

  ngOnInit() {
    this.boardName = localStorage.getItem("loginType");
    this.service.setActiveMenuName(true);
  }

}
