import { Component, OnInit } from '@angular/core';
import {CoreService} from "../../core/services/core.service"
import { core } from '@angular/compiler';

@Component({
  selector: 'app-transcation',
  templateUrl: './transcation.component.html',
  styleUrls: ['./transcation.component.scss']
})
export class TranscationComponent implements OnInit {

  public loginType:string;
  public transcation;

  constructor(public service:CoreService) { }

  ngOnInit() {
    this.loginType = localStorage.getItem("loginType");
    this.service.getTranscation().subscribe(data => {
      this.transcation = data;
    });
  }

}
