import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {ProductSdecComponent} from "./SDEC/products.sdec.component";
import {ProductCdcComponent} from "./CDC/products.cdc.component";
import {ProductStoreComponent} from "./STORES/products.store.component";



const routes: Routes = [
    {
        path: 'sedc',
        component: ProductSdecComponent,
        data: {title: 'Add Products'}
    },
    {
        path: 'cdc',
        component: ProductStoreComponent,
        data: {title: 'Dashboard'}
    },
    {
        path: 'stores',
        component: ProductStoreComponent,
        data: {title: 'Transcation'}
    },
];

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ],
    exports: [RouterModule]
})
export class SecureRoutingModule {
}
