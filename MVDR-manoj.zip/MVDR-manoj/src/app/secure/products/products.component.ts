import { Component, OnInit } from '@angular/core';
import {CoreService} from "../../core/services/core.service";


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

   activeLoginType:any;

  constructor(public service:CoreService) { 
    
  }

  ngOnInit() {
    this.activeLoginType = localStorage.getItem("loginType");
    this.service.setActiveMenuName(true);
  }

}
