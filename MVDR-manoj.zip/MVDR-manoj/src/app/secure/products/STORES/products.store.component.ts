import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'store-add-products',
  templateUrl: './products.store.component.html',
  styleUrls: ['./products.store.component.scss']
})
export class ProductStoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  addProdcut(){}

}
