import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductSdecComponent } from './products.sdec.component';

describe('ProductSdecComponent', () => {
  let component: ProductSdecComponent;
  let fixture: ComponentFixture<ProductSdecComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductSdecComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductSdecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
