import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'sdec-add-products',
  templateUrl: './products.sdec.component.html',
  styleUrls: ['./products.sdec.component.scss']
})
export class ProductSdecComponent implements OnInit {

  
  public model={};
  constructor() { }

  ngOnInit() {
  }

  addProdcut(){}


}
