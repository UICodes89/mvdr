import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductCdcComponent } from './products.cdc.component';

describe('ProductCdcComponent', () => {
  let component: ProductCdcComponent;
  let fixture: ComponentFixture<ProductCdcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductCdcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductCdcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
