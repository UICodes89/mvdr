import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'cdc-add-products',
  templateUrl: './products.cdc.component.html',
  styleUrls: ['./products.cdc.component.scss']
})
export class ProductCdcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  addProdcut(){}

}
